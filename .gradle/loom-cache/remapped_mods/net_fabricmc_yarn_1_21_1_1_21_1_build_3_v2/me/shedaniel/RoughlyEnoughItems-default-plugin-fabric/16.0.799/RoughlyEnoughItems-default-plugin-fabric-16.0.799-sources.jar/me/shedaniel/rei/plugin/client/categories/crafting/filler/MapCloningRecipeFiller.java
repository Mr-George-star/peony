/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.plugin.client.categories.crafting.filler;

import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.plugin.common.displays.crafting.DefaultCustomShapelessDisplay;
import net.minecraft.item.Items;
import net.minecraft.recipe.MapCloningRecipe;
import net.minecraft.recipe.RecipeEntry;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class MapCloningRecipeFiller implements CraftingRecipeFiller<MapCloningRecipe> {
    @Override
    public Collection<Display> apply(RecipeEntry<MapCloningRecipe> recipe) {
        List<Display> displays = new ArrayList<>();
        
        displays.add(new DefaultCustomShapelessDisplay(recipe,
                List.of(EntryIngredients.of(Items.FILLED_MAP), EntryIngredients.of(Items.MAP)),
                List.of(EntryIngredients.of(Items.FILLED_MAP, 2))));
        
        return displays;
    }
    
    @Override
    public Class<MapCloningRecipe> getRecipeClass() {
        return MapCloningRecipe.class;
    }
}
