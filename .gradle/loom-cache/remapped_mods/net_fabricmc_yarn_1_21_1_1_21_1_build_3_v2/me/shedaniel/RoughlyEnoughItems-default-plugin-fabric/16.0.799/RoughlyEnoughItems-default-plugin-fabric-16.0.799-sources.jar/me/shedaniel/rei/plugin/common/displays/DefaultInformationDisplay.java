/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.plugin.common.displays;

import com.google.common.collect.Lists;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.display.basic.BasicDisplay;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.plugin.common.BuiltinPlugin;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.text.Text;
import java.util.*;

public class DefaultInformationDisplay implements Display {
    private EntryIngredient entryStacks;
    private List<Text> texts;
    private Text name;
    
    protected DefaultInformationDisplay(EntryIngredient entryStacks, Text name) {
        this.entryStacks = entryStacks;
        this.name = name;
        this.texts = Lists.newArrayList();
    }
    
    public static DefaultInformationDisplay createFromEntries(EntryIngredient entryStacks, Text name) {
        return new DefaultInformationDisplay(entryStacks, name);
    }
    
    public static DefaultInformationDisplay createFromEntry(EntryStack<?> entryStack, Text name) {
        return createFromEntries(EntryIngredient.of(entryStack), name);
    }
    
    @Override
    public List<EntryIngredient> getInputEntries() {
        return Collections.singletonList(entryStacks);
    }
    
    @Override
    public List<EntryIngredient> getOutputEntries() {
        return Collections.singletonList(entryStacks);
    }
    
    public DefaultInformationDisplay line(Text line) {
        texts.add(line);
        return this;
    }
    
    public DefaultInformationDisplay lines(Text... lines) {
        texts.addAll(Arrays.asList(lines));
        return this;
    }
    
    public DefaultInformationDisplay lines(Collection<Text> lines) {
        texts.addAll(lines);
        return this;
    }
    
    public EntryIngredient getEntryStacks() {
        return entryStacks;
    }
    
    public Text getName() {
        return name;
    }
    
    public List<Text> getTexts() {
        return texts;
    }
    
    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return BuiltinPlugin.INFO;
    }
    
    public static DisplaySerializer<DefaultInformationDisplay> serializer() {
        return new DisplaySerializer<DefaultInformationDisplay>() {
            @Override
            public NbtCompound save(NbtCompound tag, DefaultInformationDisplay display) {
                tag.put("stacks", display.getEntryStacks().saveIngredient());
                tag.putString("name", Text.Serialization.toJsonString(display.getName(), BasicDisplay.registryAccess()));
                NbtList descriptions = new NbtList();
                for (Text text : display.getTexts()) {
                    descriptions.add(NbtString.of(Text.Serialization.toJsonString(text, BasicDisplay.registryAccess())));
                }
                tag.put("descriptions", descriptions);
                return tag;
            }
            
            @Override
            public DefaultInformationDisplay read(NbtCompound tag) {
                EntryIngredient stacks = EntryIngredient.read(tag.getList("stacks", NbtElement.COMPOUND_TYPE));
                Text name = Text.Serialization.fromJson(tag.getString("name"), BasicDisplay.registryAccess());
                List<Text> descriptions = new ArrayList<>();
                for (NbtElement descriptionTag : tag.getList("descriptions", NbtElement.STRING_TYPE)) {
                    descriptions.add(Text.Serialization.fromJson(descriptionTag.asString(), BasicDisplay.registryAccess()));
                }
                return new DefaultInformationDisplay(stacks, name).lines(descriptions);
            }
        };
    }
}
