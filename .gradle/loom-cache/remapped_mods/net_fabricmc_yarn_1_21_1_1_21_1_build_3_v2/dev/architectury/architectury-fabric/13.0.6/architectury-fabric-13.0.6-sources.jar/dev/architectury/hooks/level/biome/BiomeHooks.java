/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.level.biome;

import dev.architectury.injectables.annotations.ExpectPlatform;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.BiomeAdditionsSound;
import net.minecraft.sound.BiomeMoodSound;
import net.minecraft.sound.MusicSound;
import net.minecraft.sound.SoundEvent;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeEffects;
import net.minecraft.world.biome.BiomeEffects.GrassColorModifier;
import net.minecraft.world.biome.BiomeParticleConfig;
import net.minecraft.world.biome.GenerationSettings;
import net.minecraft.world.biome.SpawnSettings;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.carver.ConfiguredCarver;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.level.biome.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public final class BiomeHooks {
    public static BiomeProperties getBiomeProperties(Biome biome) {
        return new BiomeWrapped(biome);
    }
    
    public static class BiomeWrapped implements BiomeProperties {
        protected final Biome biome;
        protected final ClimateProperties climateProperties;
        protected final EffectsProperties effectsProperties;
        protected final GenerationProperties generationProperties;
        protected final SpawnProperties spawnProperties;
        
        public BiomeWrapped(Biome biome) {
            this(biome,
                    new ClimateWrapped(biome),
                    new EffectsWrapped(biome),
                    new GenerationSettingsWrapped(biome),
                    new SpawnSettingsWrapped(biome));
        }
        
        public BiomeWrapped(Biome biome,
                            ClimateProperties climateProperties,
                            EffectsProperties effectsProperties,
                            GenerationProperties generationProperties,
                            SpawnProperties spawnProperties) {
            this.biome = biome;
            this.climateProperties = climateProperties;
            this.effectsProperties = effectsProperties;
            this.generationProperties = generationProperties;
            this.spawnProperties = spawnProperties;
        }
        
        @Override
        public ClimateProperties getClimateProperties() {
            return climateProperties;
        }
        
        @Override
        public EffectsProperties getEffectsProperties() {
            return effectsProperties;
        }
        
        @Override
        public GenerationProperties getGenerationProperties() {
            return generationProperties;
        }
        
        @Override
        public SpawnProperties getSpawnProperties() {
            return spawnProperties;
        }
    }
    
    public static class MutableBiomeWrapped extends BiomeWrapped implements BiomeProperties.Mutable {
        public MutableBiomeWrapped(Biome biome,
                                   GenerationProperties.Mutable generationProperties,
                                   SpawnProperties.Mutable spawnProperties) {
            this(biome,
                    new ClimateWrapped(extractClimateSettings(biome)),
                    new EffectsWrapped(biome.getEffects()),
                    generationProperties,
                    spawnProperties);
        }
        
        public MutableBiomeWrapped(Biome biome,
                                   ClimateProperties.Mutable climateProperties,
                                   EffectsProperties.Mutable effectsProperties,
                                   GenerationProperties.Mutable generationProperties,
                                   SpawnProperties.Mutable spawnProperties) {
            super(biome,
                    climateProperties,
                    effectsProperties,
                    generationProperties,
                    spawnProperties);
        }
        
        @Override
        public ClimateProperties.Mutable getClimateProperties() {
            return (ClimateProperties.Mutable) super.getClimateProperties();
        }
        
        @Override
        public EffectsProperties.Mutable getEffectsProperties() {
            return (EffectsProperties.Mutable) super.getEffectsProperties();
        }
        
        @Override
        public GenerationProperties.Mutable getGenerationProperties() {
            return (GenerationProperties.Mutable) super.getGenerationProperties();
        }
        
        @Override
        public SpawnProperties.Mutable getSpawnProperties() {
            return (SpawnProperties.Mutable) super.getSpawnProperties();
        }
    }
    
    @ExpectPlatform
    private static Biome.Weather extractClimateSettings(Biome biome) {
        return null;
    }
    
    public static class ClimateWrapped implements ClimateProperties.Mutable {
        
        protected final Biome.Weather climateSettings;
        
        public ClimateWrapped(Biome biome) {
            this(extractClimateSettings(biome));
        }
        
        public ClimateWrapped(Biome.Weather climateSettings) {
            this.climateSettings = climateSettings;
        }
        
        @Override
        public Mutable setHasPrecipitation(boolean hasPrecipitation) {
            climateSettings.comp_1187 = hasPrecipitation;
            return this;
        }
        
        @Override
        public Mutable setTemperature(float temperature) {
            climateSettings.comp_844 = temperature;
            return this;
        }
        
        @Override
        public Mutable setTemperatureModifier(Biome.TemperatureModifier temperatureModifier) {
            climateSettings.comp_845 = temperatureModifier;
            return this;
        }
        
        @Override
        public Mutable setDownfall(float downfall) {
            climateSettings.comp_846 = downfall;
            return this;
        }
        
        @Override
        public boolean hasPrecipitation() {
            return climateSettings.comp_1187;
        }
        
        @Override
        public float getTemperature() {
            return climateSettings.comp_844;
        }
        
        @Override
        public Biome.TemperatureModifier getTemperatureModifier() {
            return climateSettings.comp_845;
        }
        
        @Override
        public float getDownfall() {
            return climateSettings.comp_846;
        }
    }
    
    public static class EffectsWrapped implements EffectsProperties.Mutable {
        protected final BiomeEffects effects;
        
        public EffectsWrapped(Biome biome) {
            this(biome.getEffects());
        }
        
        public EffectsWrapped(BiomeEffects effects) {
            this.effects = effects;
        }
        
        @Override
        public EffectsProperties.Mutable setFogColor(int color) {
            effects.fogColor = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setWaterColor(int color) {
            effects.waterColor = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setWaterFogColor(int color) {
            effects.waterFogColor = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setSkyColor(int color) {
            effects.skyColor = color;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setFoliageColorOverride(@Nullable Integer colorOverride) {
            effects.foliageColor = Optional.ofNullable(colorOverride);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setGrassColorOverride(@Nullable Integer colorOverride) {
            effects.grassColor = Optional.ofNullable(colorOverride);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setGrassColorModifier(GrassColorModifier modifier) {
            effects.grassColorModifier = modifier;
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientParticle(@Nullable BiomeParticleConfig settings) {
            effects.particleConfig = Optional.ofNullable(settings);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientLoopSound(@Nullable RegistryEntry<SoundEvent> sound) {
            effects.loopSound = Optional.ofNullable(sound);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientMoodSound(@Nullable BiomeMoodSound settings) {
            effects.moodSound = Optional.ofNullable(settings);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setAmbientAdditionsSound(@Nullable BiomeAdditionsSound settings) {
            effects.additionsSound = Optional.ofNullable(settings);
            return this;
        }
        
        @Override
        public EffectsProperties.Mutable setBackgroundMusic(@Nullable MusicSound music) {
            effects.music = Optional.ofNullable(music);
            return this;
        }
        
        @Override
        public int getFogColor() {
            return effects.fogColor;
        }
        
        @Override
        public int getWaterColor() {
            return effects.waterColor;
        }
        
        @Override
        public int getWaterFogColor() {
            return effects.waterFogColor;
        }
        
        @Override
        public int getSkyColor() {
            return effects.skyColor;
        }
        
        @Override
        public OptionalInt getFoliageColorOverride() {
            return effects.foliageColor.map(OptionalInt::of).orElseGet(OptionalInt::empty);
        }
        
        @Override
        public OptionalInt getGrassColorOverride() {
            return effects.grassColor.map(OptionalInt::of).orElseGet(OptionalInt::empty);
        }
        
        @Override
        public GrassColorModifier getGrassColorModifier() {
            return effects.grassColorModifier;
        }
        
        @Override
        public Optional<BiomeParticleConfig> getAmbientParticle() {
            return effects.particleConfig;
        }
        
        @Override
        public Optional<RegistryEntry<SoundEvent>> getAmbientLoopSound() {
            return effects.loopSound;
        }
        
        @Override
        public Optional<BiomeMoodSound> getAmbientMoodSound() {
            return effects.moodSound;
        }
        
        @Override
        public Optional<BiomeAdditionsSound> getAmbientAdditionsSound() {
            return effects.additionsSound;
        }
        
        @Override
        public Optional<MusicSound> getBackgroundMusic() {
            return effects.music;
        }
    }
    
    public static class GenerationSettingsWrapped implements GenerationProperties {
        protected final GenerationSettings settings;
        
        public GenerationSettingsWrapped(Biome biome) {
            this(biome.getGenerationSettings());
        }
        
        public GenerationSettingsWrapped(GenerationSettings settings) {
            this.settings = settings;
        }
        
        @Override
        public Iterable<RegistryEntry<ConfiguredCarver<?>>> getCarvers(GenerationStep.Carver carving) {
            return settings.getCarversForStep(carving);
        }
        
        @Override
        public Iterable<RegistryEntry<PlacedFeature>> getFeatures(GenerationStep.Feature decoration) {
            if (decoration.ordinal() >= settings.getFeatures().size()) {
                return Collections.emptyList();
            }
            return settings.getFeatures().get(decoration.ordinal());
        }
        
        @Override
        public List<Iterable<RegistryEntry<PlacedFeature>>> getFeatures() {
            return (List<Iterable<RegistryEntry<PlacedFeature>>>) (List<?>) settings.getFeatures();
        }
    }
    
    public static class SpawnSettingsWrapped implements SpawnProperties {
        protected final SpawnSettings settings;
        
        public SpawnSettingsWrapped(Biome biome) {
            this(biome.getSpawnSettings());
        }
        
        public SpawnSettingsWrapped(SpawnSettings settings) {
            this.settings = settings;
        }
        
        @Override
        public float getCreatureProbability() {
            return this.settings.getCreatureSpawnProbability();
        }
        
        @Override
        public Map<SpawnGroup, List<SpawnSettings.SpawnEntry>> getSpawners() {
            return null;
        }
        
        @Override
        public Map<EntityType<?>, SpawnSettings.SpawnDensity> getMobSpawnCosts() {
            return null;
        }
    }
}
