/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.networking;

import dev.architectury.impl.NetworkAggregator;
import dev.architectury.injectables.annotations.ExpectPlatform;
import dev.architectury.networking.transformers.PacketCollector;
import dev.architectury.networking.transformers.PacketSink;
import dev.architectury.networking.transformers.PacketTransformer;
import dev.architectury.networking.transformers.SinglePacketCollector;
import dev.architectury.utils.Env;
import dev.architectury.utils.GameInstance;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.server.network.EntityTrackerEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class NetworkManager {
    /**
     * For S2C types, {@link #registerReceiver} should be called on the client side,
     * while {@link #registerS2CPayloadType} should be called on the server side.
     */
    @Deprecated(forRemoval = true)
    public static void registerS2CPayloadType(Identifier id) {
        NetworkAggregator.registerS2CType(id, List.of());
    }
    
    /**
     * For S2C types, {@link #registerReceiver} should be called on the client side,
     * while {@link #registerS2CPayloadType} should be called on the server side.
     */
    public static <T extends CustomPayload> void registerS2CPayloadType(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec) {
        NetworkAggregator.registerS2CType(type, codec, List.of());
    }
    
    /**
     * For S2C types, {@link #registerReceiver} should be called on the client side,
     * while {@link #registerS2CPayloadType} should be called on the server side.
     */
    @Deprecated(forRemoval = true)
    public static void registerS2CPayloadType(Identifier id, List<PacketTransformer> packetTransformers) {
        NetworkAggregator.registerS2CType(id, packetTransformers);
    }
    
    /**
     * For S2C types, {@link #registerReceiver} should be called on the client side,
     * while {@link #registerS2CPayloadType} should be called on the server side.
     */
    public static <T extends CustomPayload> void registerS2CPayloadType(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, List<PacketTransformer> packetTransformers) {
        NetworkAggregator.registerS2CType(type, codec, packetTransformers);
    }
    
    @Deprecated(forRemoval = true)
    public static void registerReceiver(Side side, Identifier id, NetworkReceiver<RegistryByteBuf> receiver) {
        registerReceiver(side, id, Collections.emptyList(), receiver);
    }
    
    @ApiStatus.Experimental
    @Deprecated(forRemoval = true)
    public static void registerReceiver(Side side, Identifier id, List<PacketTransformer> packetTransformers, NetworkReceiver<RegistryByteBuf> receiver) {
        NetworkAggregator.registerReceiver(side, id, packetTransformers, receiver);
    }
    
    public static <T extends CustomPayload> void registerReceiver(Side side, CustomPayload.Id<T> id, PacketCodec<? super RegistryByteBuf, T> codec, NetworkReceiver<T> receiver) {
        registerReceiver(side, id, codec, Collections.emptyList(), receiver);
    }
    
    @ApiStatus.Experimental
    public static <T extends CustomPayload> void registerReceiver(Side side, CustomPayload.Id<T> id, PacketCodec<? super RegistryByteBuf, T> codec, List<PacketTransformer> packetTransformers, NetworkReceiver<T> receiver) {
        NetworkAggregator.registerReceiver(side, id, codec, packetTransformers, receiver);
    }
    
    @Deprecated(forRemoval = true)
    public static Packet<?> toPacket(Side side, Identifier id, RegistryByteBuf buf) {
        SinglePacketCollector sink = new SinglePacketCollector(null);
        collectPackets(sink, side, id, buf);
        return sink.getPacket();
    }
    
    @Deprecated(forRemoval = true)
    public static List<Packet<?>> toPackets(Side side, Identifier id, RegistryByteBuf buf) {
        PacketCollector sink = new PacketCollector(null);
        collectPackets(sink, side, id, buf);
        return sink.collect();
    }
    
    public static <T extends CustomPayload> Packet<?> toPacket(Side side, T payload, DynamicRegistryManager access) {
        SinglePacketCollector sink = new SinglePacketCollector(null);
        collectPackets(sink, side, payload, access);
        return sink.getPacket();
    }
    
    public static <T extends CustomPayload> List<Packet<?>> toPackets(Side side, T payload, DynamicRegistryManager access) {
        PacketCollector sink = new PacketCollector(null);
        collectPackets(sink, side, payload, access);
        return sink.collect();
    }
    
    @Deprecated(forRemoval = true)
    public static void collectPackets(PacketSink sink, Side side, Identifier id, RegistryByteBuf buf) {
        NetworkAggregator.collectPackets(sink, side, id, buf);
    }
    
    public static <T extends CustomPayload> void collectPackets(PacketSink sink, Side side, T payload, DynamicRegistryManager access) {
        NetworkAggregator.collectPackets(sink, side, payload, access);
    }
    
    @Deprecated(forRemoval = true)
    public static void sendToPlayer(ServerPlayerEntity player, Identifier id, RegistryByteBuf buf) {
        collectPackets(PacketSink.ofPlayer(player), serverToClient(), id, buf);
    }
    
    @Deprecated(forRemoval = true)
    public static void sendToPlayers(Iterable<ServerPlayerEntity> players, Identifier id, RegistryByteBuf buf) {
        collectPackets(PacketSink.ofPlayers(players), serverToClient(), id, buf);
    }
    
    @Environment(EnvType.CLIENT)
    @Deprecated(forRemoval = true)
    public static void sendToServer(Identifier id, RegistryByteBuf buf) {
        collectPackets(PacketSink.client(), clientToServer(), id, buf);
    }
    
    public static <T extends CustomPayload> void sendToPlayer(ServerPlayerEntity player, T payload) {
        collectPackets(PacketSink.ofPlayer(player), serverToClient(), payload, player.getRegistryManager());
    }
    
    public static <T extends CustomPayload> void sendToPlayers(Iterable<ServerPlayerEntity> players, T payload) {
        Iterator<ServerPlayerEntity> iterator = players.iterator();
        if (!iterator.hasNext()) return;
        collectPackets(PacketSink.ofPlayers(players), serverToClient(), payload, iterator.next().getRegistryManager());
    }
    
    @Environment(EnvType.CLIENT)
    public static <T extends CustomPayload> void sendToServer(T payload) {
        ClientPlayNetworkHandler connection = GameInstance.getClient().getNetworkHandler();
        if (connection == null) return;
        collectPackets(PacketSink.client(), clientToServer(), payload, connection.getRegistryManager());
    }
    
    @Environment(EnvType.CLIENT)
    @ExpectPlatform
    public static boolean canServerReceive(Identifier id) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    public static boolean canPlayerReceive(ServerPlayerEntity player, Identifier id) {
        throw new AssertionError();
    }
    
    @Environment(EnvType.CLIENT)
    public static boolean canServerReceive(CustomPayload.Id<?> type) {
        return canServerReceive(type.id());
    }
    
    public static boolean canPlayerReceive(ServerPlayerEntity player, CustomPayload.Id<?> type) {
        return canPlayerReceive(player, type.id());
    }
    
    /**
     * Easy to use utility method to create an entity spawn packet.
     * This packet is needed everytime any mod adds a non-living entity.
     * The entity should override {@link Entity#createSpawnPacket()} to point to this method!
     * <p>
     * Additionally, entities may implement {@link dev.architectury.extensions.network.EntitySpawnExtension}
     * to load / save additional data to the client.
     *
     * @param entity The entity which should be spawned.
     * @return The ready to use packet to spawn the entity on the client.
     * @see Entity#createSpawnPacket()
     */
    @ExpectPlatform
    public static Packet<ClientPlayPacketListener> createAddEntityPacket(Entity entity, EntityTrackerEntry serverEntity) {
        throw new AssertionError();
    }
    
    @ExpectPlatform
    private static NetworkAggregator.Adaptor getAdaptor() {
        throw new AssertionError();
    }
    
    @FunctionalInterface
    public interface NetworkReceiver<T> {
        void receive(T value, PacketContext context);
    }
    
    public interface PacketContext {
        PlayerEntity getPlayer();
        
        void queue(Runnable runnable);
        
        Env getEnvironment();
        
        DynamicRegistryManager registryAccess();
        
        default EnvType getEnv() {
            return getEnvironment().toPlatform();
        }
    }
    
    public static Side s2c() {
        return Side.S2C;
    }
    
    public static Side c2s() {
        return Side.C2S;
    }
    
    public static Side serverToClient() {
        return Side.S2C;
    }
    
    public static Side clientToServer() {
        return Side.C2S;
    }
    
    public enum Side {
        S2C,
        C2S
    }
}
