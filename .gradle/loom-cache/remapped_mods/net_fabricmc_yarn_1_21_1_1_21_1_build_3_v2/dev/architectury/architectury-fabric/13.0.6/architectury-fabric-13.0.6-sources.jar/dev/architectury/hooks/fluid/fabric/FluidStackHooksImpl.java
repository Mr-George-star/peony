/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.fluid.fabric;

import com.mojang.logging.LogUtils;
import dev.architectury.fluid.FluidStack;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.client.texture.Sprite;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

import java.util.Optional;

public class FluidStackHooksImpl {
    private static final Logger LOGGER = LogUtils.getLogger();
    
    public static Text getName(FluidStack stack) {
        return FluidVariantAttributes.getName(FluidStackHooksFabric.toFabric(stack));
    }
    
    public static String getTranslationKey(FluidStack stack) {
        var id = Registries.FLUID.getId(stack.getFluid());
        return "block." + id.getNamespace() + "." + id.getPath();
    }
    
    public static FluidStack read(RegistryByteBuf buf) {
        return FluidStack.STREAM_CODEC.decode(buf);
    }
    
    public static void write(FluidStack stack, RegistryByteBuf buf) {
        FluidStack.STREAM_CODEC.encode(buf, stack);
    }
    
    public static Optional<FluidStack> read(RegistryWrapper.WrapperLookup provider, NbtElement tag) {
        return FluidStack.CODEC.parse(provider.getOps(NbtOps.INSTANCE), tag)
                .resultOrPartial(string -> LOGGER.error("Tried to load invalid fluid stack: '{}'", string));
    }
    
    public static FluidStack readOptional(RegistryWrapper.WrapperLookup provider, NbtCompound tag) {
        return tag.isEmpty() ? FluidStack.empty() : read(provider, tag).orElse(FluidStack.empty());
    }
    
    public static NbtElement write(RegistryWrapper.WrapperLookup provider, FluidStack stack, NbtElement tag) {
        return FluidStack.CODEC.encode(stack, provider.getOps(NbtOps.INSTANCE), tag).getOrThrow(IllegalStateException::new);
    }
    
    public static long bucketAmount() {
        return 81000;
    }
    
    @Environment(EnvType.CLIENT)
    @Nullable
    public static Sprite getStillTexture(@Nullable BlockRenderView level, @Nullable BlockPos pos, FluidState state) {
        if (state.getFluid() == Fluids.EMPTY) return null;
        var handler = FluidRenderHandlerRegistry.INSTANCE.get(state.getFluid());
        if (handler == null) return null;
        var sprites = handler.getFluidSprites(level, pos, state);
        if (sprites == null) return null;
        return sprites[0];
    }
    
    @Environment(EnvType.CLIENT)
    @Nullable
    public static Sprite getStillTexture(FluidStack stack) {
        var sprites = FluidVariantRendering.getSprites(FluidStackHooksFabric.toFabric(stack));
        return sprites == null ? null : sprites[0];
    }
    
    @Environment(EnvType.CLIENT)
    @Nullable
    public static Sprite getStillTexture(Fluid fluid) {
        var sprites = FluidVariantRendering.getSprites(FluidVariant.of(fluid));
        return sprites == null ? null : sprites[0];
    }
    
    @Environment(EnvType.CLIENT)
    @Nullable
    public static Sprite getFlowingTexture(@Nullable BlockRenderView level, @Nullable BlockPos pos, FluidState state) {
        if (state.getFluid() == Fluids.EMPTY) return null;
        var handler = FluidRenderHandlerRegistry.INSTANCE.get(state.getFluid());
        if (handler == null) return null;
        var sprites = handler.getFluidSprites(level, pos, state);
        if (sprites == null) return null;
        return sprites[1];
    }
    
    @Environment(EnvType.CLIENT)
    @Nullable
    public static Sprite getFlowingTexture(FluidStack stack) {
        var sprites = FluidVariantRendering.getSprites(FluidStackHooksFabric.toFabric(stack));
        return sprites == null ? null : sprites[1];
    }
    
    @Environment(EnvType.CLIENT)
    @Nullable
    public static Sprite getFlowingTexture(Fluid fluid) {
        var sprites = FluidVariantRendering.getSprites(FluidVariant.of(fluid));
        return sprites == null ? null : sprites[1];
    }
    
    @Environment(EnvType.CLIENT)
    public static int getColor(@Nullable BlockRenderView level, @Nullable BlockPos pos, FluidState state) {
        if (state.getFluid() == Fluids.EMPTY) return -1;
        var handler = FluidRenderHandlerRegistry.INSTANCE.get(state.getFluid());
        if (handler == null) return -1;
        return handler.getFluidColor(level, pos, state);
    }
    
    @Environment(EnvType.CLIENT)
    public static int getColor(FluidStack stack) {
         return FluidVariantRendering.getColor(FluidStackHooksFabric.toFabric(stack));
    }
    
    @Environment(EnvType.CLIENT)
    public static int getColor(Fluid fluid) {
        if (fluid == Fluids.EMPTY) return -1;
        var handler = FluidRenderHandlerRegistry.INSTANCE.get(fluid);
        if (handler == null) return -1;
        return handler.getFluidColor(null, null, fluid.getDefaultState());
    }
    
    public static int getLuminosity(FluidStack fluid, @Nullable World level, @Nullable BlockPos pos) {
        return FluidVariantAttributes.getLuminance(FluidStackHooksFabric.toFabric(fluid));
    }
    
    public static int getLuminosity(Fluid fluid, @Nullable World level, @Nullable BlockPos pos) {
        return FluidVariantAttributes.getLuminance(FluidVariant.of(fluid));
    }
    
    public static int getTemperature(FluidStack fluid, @Nullable World level, @Nullable BlockPos pos) {
        return FluidVariantAttributes.getTemperature(FluidStackHooksFabric.toFabric(fluid));
    }
    
    public static int getTemperature(Fluid fluid, @Nullable World level, @Nullable BlockPos pos) {
        return FluidVariantAttributes.getTemperature(FluidVariant.of(fluid));
    }
    
    public static int getViscosity(FluidStack fluid, @Nullable World level, @Nullable BlockPos pos) {
        return FluidVariantAttributes.getViscosity(FluidStackHooksFabric.toFabric(fluid), level);
    }
    
    public static int getViscosity(Fluid fluid, @Nullable World level, @Nullable BlockPos pos) {
        return FluidVariantAttributes.getViscosity(FluidVariant.of(fluid), level);
    }
}
