/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.registry;

import dev.architectury.injectables.annotations.ExpectPlatform;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import net.minecraft.resource.ResourceReloader;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

public final class ReloadListenerRegistry {
    private ReloadListenerRegistry() {
    }
    
    public static void register(ResourceType type, ResourceReloader listener) {
        register(type, listener, null);
    }
    
    public static void register(ResourceType type, ResourceReloader listener, @Nullable Identifier listenerId) {
        register(type, listener, listenerId, List.of());
    }
    
    @ExpectPlatform
    public static void register(ResourceType type, ResourceReloader listener, @Nullable Identifier listenerId, Collection<Identifier> dependencies) {
        throw new AssertionError();
    }
}
