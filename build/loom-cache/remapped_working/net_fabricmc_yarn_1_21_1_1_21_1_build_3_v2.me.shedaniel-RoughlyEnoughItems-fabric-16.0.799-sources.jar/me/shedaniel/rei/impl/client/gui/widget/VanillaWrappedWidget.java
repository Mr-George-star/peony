/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.gui.widget;

import me.shedaniel.rei.api.client.gui.widgets.Widget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.ParentElement;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class VanillaWrappedWidget extends Widget {
    private Element element;
    
    public VanillaWrappedWidget(Element element) {
        this.element = Objects.requireNonNull(element);
        setFocused(element);
    }
    
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        if (element instanceof Widget widget) {
            widget.render(graphics, mouseX, mouseY, delta);
        } else {
            graphics.getMatrices().push();
            if (element instanceof Drawable widget)
                widget.render(graphics, mouseX, mouseY, delta);
            graphics.getMatrices().pop();
        }
    }
    
    @Override
    public List<? extends Element> children() {
        return Collections.singletonList(element);
    }
    
    @Nullable
    @Override
    public Element getFocused() {
        return element;
    }
    
    @Override
    public void setFocused(@Nullable Element guiEventListener) {
        if (guiEventListener == element) {
            super.setFocused(element);
        } else if (element instanceof ParentElement handler) {
            handler.setFocused(guiEventListener);
        }
    }
    
    @Override
    public boolean isDragging() {
        return true;
    }
    
    @Override
    public boolean containsMouse(double mouseX, double mouseY) {
        return element.isMouseOver(mouseX, mouseY);
    }
}