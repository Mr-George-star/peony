/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.config.entries;

import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.widgets.Label;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.category.CategoryRegistry;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.impl.client.gui.widget.UpdatedListWidget;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Language;
import java.util.*;
import java.util.function.Supplier;

public class ConfigureCategoriesScreen extends Screen {
    private final Map<CategoryIdentifier<?>, Boolean> filteringQuickCraftCategories;
    private final Set<CategoryIdentifier<?>> hiddenCategories;
    private final List<CategoryIdentifier<?>> categoryOrdering;
    private ListWidget listWidget;
    public Runnable editedSink = () -> {
    };
    public Screen parent;
    
    public ConfigureCategoriesScreen(Map<CategoryIdentifier<?>, Boolean> filteringQuickCraftCategories, Set<CategoryIdentifier<?>> hiddenCategories, List<CategoryIdentifier<?>> categoryOrdering) {
        super(Text.translatable("config.roughlyenoughitems.configureCategories.title"));
        this.filteringQuickCraftCategories = filteringQuickCraftCategories;
        this.hiddenCategories = hiddenCategories;
        this.categoryOrdering = categoryOrdering;
        for (CategoryRegistry.CategoryConfiguration<?> configuration : CategoryRegistry.getInstance()) {
            if (!this.categoryOrdering.contains(configuration.getCategoryIdentifier())) {
                this.categoryOrdering.add(configuration.getCategoryIdentifier());
            }
        }
    }
    
    public Map<CategoryIdentifier<?>, Boolean> getFilteringQuickCraftCategories() {
        return filteringQuickCraftCategories;
    }
    
    public Set<CategoryIdentifier<?>> getHiddenCategories() {
        return hiddenCategories;
    }
    
    public List<CategoryIdentifier<?>> getCategoryOrdering() {
        return categoryOrdering;
    }
    
    @Override
    public void init() {
        super.init();
        {
            Text backText = Text.literal("↩ ").append(Text.translatable("gui.back"));
            addDrawableChild(new ButtonWidget(4, 4, MinecraftClient.getInstance().textRenderer.getWidth(backText) + 10, 20, backText, button -> {
                client.setScreen(parent);
                this.parent = null;
            }, Supplier::get) {
            });
        }
        listWidget = addSelectableChild(new ListWidget(client, width, height, 30, height));
        this.resetListEntries();
    }
    
    public void resetListEntries() {
        listWidget.children().clear();
        List<CategoryRegistry.CategoryConfiguration<?>> configurations = new ArrayList<>(CategoryRegistry.getInstance().stream().toList());
        configurations.sort(Comparator.comparingInt(o -> {
            int indexOf = categoryOrdering.indexOf(o.getCategoryIdentifier());
            return indexOf == -1 ? Integer.MAX_VALUE : indexOf;
        }));
        for (CategoryRegistry.CategoryConfiguration<?> configuration : configurations) {
            listWidget.addItem(new DefaultListEntry(configuration));
        }
    }
    
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        super.render(graphics, mouseX, mouseY, delta);
        this.listWidget.render(graphics, mouseX, mouseY, delta);
        graphics.drawTextWithShadow(this.textRenderer, this.title.asOrderedText(), (int) (this.width / 2.0F - this.textRenderer.getWidth(this.title) / 2.0F), 12, -1);
    }
    
    @Override
    public void close() {
        this.client.setScreen(parent);
    }
    
    private static class ListWidget extends UpdatedListWidget<ListEntry> {
        private boolean inFocus;
        
        public ListWidget(MinecraftClient client, int width, int height, int top, int bottom) {
            super(client, width, height, top, bottom);
        }
        
        @Override
        protected boolean isSelected(int index) {
            return false;
        }
        
        @Override
        public ListEntry getSelectedItem() {
            return null;
        }
        
        @Override
        protected int addItem(ListEntry item) {
            return super.addItem(item);
        }
        
        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (super.mouseClicked(mouseX, mouseY, button))
                return true;
            ListEntry item = getItemAtPosition(mouseX, mouseY);
            if (item != null) {
                client.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0F));
                selectItem(item);
                this.setFocused(item);
                this.setDragging(true);
                return true;
            }
            return false;
        }
        
        @Override
        public int getItemWidth() {
            return width - 40;
        }
        
        @Override
        protected int getScrollbarPosition() {
            return width - 14;
        }
    }
    
    private static abstract class ListEntry extends UpdatedListWidget.ElementEntry<ListEntry> {
        @Override
        public int getItemHeight() {
            return 45;
        }
    }
    
    private class DefaultListEntry extends ListEntry {
        private final Label visibilityToggleButton, quickCraftToggleButton;
        private final ButtonWidget upButton, downButton;
        private final CategoryRegistry.CategoryConfiguration<?> configuration;
        
        public DefaultListEntry(CategoryRegistry.CategoryConfiguration<?> configuration) {
            this.configuration = configuration;
            {
                Text toggleText = Text.translatable("config.roughlyenoughitems.filtering.filteringQuickCraftCategories.configure.toggle");
                visibilityToggleButton = Widgets.createClickableLabel(new Point(), toggleText, $ -> {
                    boolean enabled = !hiddenCategories.contains(configuration.getCategoryIdentifier());
                    if (enabled) {
                        // set to false
                        hiddenCategories.add(configuration.getCategoryIdentifier());
                    } else {
                        // set to true
                        hiddenCategories.remove(configuration.getCategoryIdentifier());
                    }
                    
                    editedSink.run();
                }).leftAligned();
                quickCraftToggleButton = Widgets.createClickableLabel(new Point(), toggleText, $ -> {
                    boolean quickCraftingEnabledByDefault = configuration.isQuickCraftingEnabledByDefault();
                    boolean enabled = filteringQuickCraftCategories.getOrDefault(configuration.getCategoryIdentifier(), quickCraftingEnabledByDefault);
                    if (enabled) {
                        // set to false
                        if (!quickCraftingEnabledByDefault) {
                            filteringQuickCraftCategories.remove(configuration.getCategoryIdentifier());
                        } else {
                            filteringQuickCraftCategories.put(configuration.getCategoryIdentifier(), false);
                        }
                    } else {
                        // set to true
                        if (quickCraftingEnabledByDefault) {
                            filteringQuickCraftCategories.remove(configuration.getCategoryIdentifier());
                        } else {
                            filteringQuickCraftCategories.put(configuration.getCategoryIdentifier(), true);
                        }
                    }
                    
                    editedSink.run();
                }).leftAligned();
            }
            {
                this.upButton = new ButtonWidget(0, 0, 20, 20, Text.literal("↑"), button -> {
                    int index = categoryOrdering.indexOf(configuration.getCategoryIdentifier());
                    if (index > 0) {
                        categoryOrdering.remove(index);
                        categoryOrdering.add(index - 1, configuration.getCategoryIdentifier());
                        editedSink.run();
                        resetListEntries();
                    }
                }, Supplier::get) {
                };
                this.downButton = new ButtonWidget(0, 0, 20, 20, Text.literal("↓"), button -> {
                    int index = categoryOrdering.indexOf(configuration.getCategoryIdentifier());
                    if (index < categoryOrdering.size() - 1) {
                        categoryOrdering.remove(index);
                        categoryOrdering.add(index + 1, configuration.getCategoryIdentifier());
                        editedSink.run();
                        resetListEntries();
                    }
                }, Supplier::get) {
                };
                this.upButton.active = categoryOrdering.indexOf(configuration.getCategoryIdentifier()) > 0;
                this.downButton.active = categoryOrdering.indexOf(configuration.getCategoryIdentifier()) < categoryOrdering.size() - 1;
            }
        }
        
        @Override
        public void render(DrawContext graphics, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isHovered, float delta) {
            if (y + entryHeight < 0 || y > height) {
                return;
            }
            
            MinecraftClient client = MinecraftClient.getInstance();
            graphics.getMatrices().push();
            graphics.getMatrices().translate(0, 0, 100);
            configuration.getCategory().getIcon().render(graphics, new Rectangle(x + 2, y, 16, 16), mouseY, mouseY, delta);
            graphics.getMatrices().pop();
            int xPos = x + 22;
            {
                Text title = configuration.getCategory().getTitle();
                int i = client.textRenderer.getWidth(title);
                if (i > entryWidth - 28) {
                    StringVisitable titleTrimmed = StringVisitable.concat(client.textRenderer.trimToWidth(title, entryWidth - 28 - client.textRenderer.getWidth("...")), StringVisitable.plain("..."));
                    graphics.drawTextWithShadow(client.textRenderer, Language.getInstance().reorder(titleTrimmed), x + 2, y + 1, 16777215);
                } else {
                    graphics.drawTextWithShadow(client.textRenderer, title.asOrderedText(), xPos, y + 1, 16777215);
                }
            }
            {
                Text id = Text.literal(configuration.getCategoryIdentifier().toString())
                        .formatted(Formatting.DARK_GRAY);
                int i = client.textRenderer.getWidth(id);
                if (i > entryWidth - 28) {
                    StringVisitable idTrimmed = StringVisitable.concat(client.textRenderer.trimToWidth(id, entryWidth - 28 - client.textRenderer.getWidth("...")), StringVisitable.plain("..."));
                    graphics.drawTextWithShadow(client.textRenderer, Language.getInstance().reorder(idTrimmed), x + 2, y + 12, 8421504);
                } else {
                    graphics.drawTextWithShadow(client.textRenderer, id.asOrderedText(), xPos, y + 12, 8421504);
                }
            }
            boolean shown = !hiddenCategories.contains(configuration.getCategoryIdentifier());
            {
                Text subtitle = Text.translatable("config.roughlyenoughitems.configureCategories.visibility." + shown)
                        .formatted(shown ? Formatting.GREEN : Formatting.RED);
                int i = graphics.drawTextWithShadow(client.textRenderer, subtitle.asOrderedText(), xPos, y + 22, 8421504);
                visibilityToggleButton.getPoint().setLocation(i + 3, y + 22);
                visibilityToggleButton.render(graphics, mouseX, mouseY, delta);
            }
            if (shown) {
                Text subtitle = Text.translatable("config.roughlyenoughitems.filtering.filteringQuickCraftCategories.configure." + filteringQuickCraftCategories.getOrDefault(configuration.getCategoryIdentifier(), configuration.isQuickCraftingEnabledByDefault()))
                        .formatted(Formatting.GRAY);
                int i = graphics.drawTextWithShadow(client.textRenderer, subtitle.asOrderedText(), xPos, y + 32, 8421504);
                quickCraftToggleButton.getPoint().setLocation(i + 3, y + 32);
                quickCraftToggleButton.render(graphics, mouseX, mouseY, delta);
            } else {
                quickCraftToggleButton.getPoint().setLocation(-12390, -12390);
            }
            upButton.setX(x + entryWidth - 20);
            upButton.setY(y + entryHeight / 2 - 21);
            upButton.render(graphics, mouseX, mouseY, delta);
            downButton.setX(x + entryWidth - 20);
            downButton.setY(y + entryHeight / 2 + 1);
            downButton.render(graphics, mouseX, mouseY, delta);
        }
        
        @Override
        public List<? extends Element> children() {
            return List.of(visibilityToggleButton, quickCraftToggleButton, upButton, downButton);
        }
        
        @Override
        public List<? extends Selectable> narratables() {
            return List.of();
        }
    }
}
