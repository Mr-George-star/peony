/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.gui.widget;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.systems.VertexSorter;
import dev.architectury.registry.ReloadListenerRegistry;
import it.unimi.dsi.fastutil.longs.Long2LongMap;
import it.unimi.dsi.fastutil.longs.Long2LongOpenHashMap;
import me.shedaniel.clothconfig2.api.LazyResettable;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.config.ConfigObject;
import me.shedaniel.rei.api.client.entry.renderer.EntryRenderer;
import me.shedaniel.rei.api.client.registry.entry.EntryRegistry;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.entry.type.VanillaEntryTypes;
import me.shedaniel.rei.api.common.util.EntryStacks;
import me.shedaniel.rei.impl.common.InternalLogger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.minecraft.util.Unit;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

import java.util.List;

public class CachedEntryListRender {
    public static final int RESOLUTION = 64;
    public static NativeImageBackedTexture cachedTexture;
    public static Identifier cachedTextureLocation;
    public static Long2LongMap hash = new Long2LongOpenHashMap();
    public static LazyResettable<RenderLayer> renderType = new LazyResettable<>(() -> class_1921.method_24048("rei_cache", class_290.field_1585, class_293.class_5596.field_27382, 256,
            class_1921.class_4688.method_23598()
                    .method_34577(new class_4668.class_4683(cachedTextureLocation, false, false))
                    .method_34578(new class_4668.class_5942(class_757::method_34542))
                    .method_23617(false)));
    
    public static class Sprite {
        public final float u0;
        public final float u1;
        public final float v0;
        public final float v1;
        
        public Sprite(float u0, float u1, float v0, float v1) {
            this.u0 = u0;
            this.u1 = u1;
            this.v0 = v0;
            this.v1 = v1;
        }
    }
    
    static {
        ReloadListenerRegistry.register(ResourceType.CLIENT_RESOURCES, (barrier, resourceManager, preparationProfiler, reloadProfiler, preparationExecutor, reloadExecutor) -> {
            return barrier.whenPrepared(Unit.INSTANCE).thenRunAsync(CachedEntryListRender::refresh, reloadExecutor);
        });
    }
    
    public static void refresh() {
        if (ConfigObject.getInstance().doesCacheEntryRendering()) {
            InternalLogger.getInstance().info("Refreshing cached entry list texture...");
        }
        if (cachedTextureLocation != null) {
            MinecraftClient.getInstance().getTextureManager().destroyTexture(cachedTextureLocation);
            cachedTextureLocation = null;
            renderType.reset();
        }
        if (cachedTexture != null) {
            cachedTexture.close();
            cachedTexture = null;
        }
        hash = new Long2LongOpenHashMap();
    }
    
    @Nullable
    public static Sprite get(EntryStack<?> stack) {
        if (stack.getType() == VanillaEntryTypes.ITEM) {
            if (stack.getNullable(EntryStack.Settings.RENDERER) != null) {
                return null;
            }
            
            if (cachedTexture == null) {
                prepare();
            }
            
            long hashExact = EntryStacks.hashExact(stack);
            
            long hashOrDefault = hash.getOrDefault(hashExact, -1L);
            if (hashOrDefault != -1L) {
                // unpack
                int x = (int) (hashOrDefault >> 32);
                int y = (int) (hashOrDefault & 0xFFFFFFFFL);
                float width = cachedTexture.getImage().getWidth();
                float height = cachedTexture.getImage().getWidth();
                return new Sprite(x * RESOLUTION / width, (x + 1) * RESOLUTION / width, y * RESOLUTION / height, (y + 1) * RESOLUTION / height);
            }
        }
        
        return null;
    }
    
    private static void prepare() {
        int side = 4;
        List<EntryStack<?>> list = EntryRegistry.getInstance().getPreFilteredList();
        while (side * side < list.size()) {
            side++;
        }
        
        int width = side * RESOLUTION;
        int height = side * RESOLUTION;
        
        InternalLogger.getInstance().info("Preparing cached texture with size %sx%s for %sx%s entries", width, height, side, side);
        
        hash = new Long2LongOpenHashMap(list.size() + 10);
        MinecraftClient minecraft = MinecraftClient.getInstance();
        SimpleFramebuffer target = new SimpleFramebuffer(width, height, true, false);
        target.beginWrite(true);
        Matrix4f projectionMatrix = new Matrix4f().setOrtho(0.0F, width, height, 0.0F, 1000.0F, 3000.0F);
        RenderSystem.setProjectionMatrix(projectionMatrix, VertexSorter.BY_Z);
        Matrix4fStack modelViewStack = RenderSystem.getModelViewStack();
        modelViewStack.pushMatrix();
        modelViewStack.identity();
        modelViewStack.translate(0.0F, 0.0F, -2000.0F);
        RenderSystem.applyModelViewMatrix();
        
        DiffuseLighting.enableGuiDepthLighting();
        Rectangle bounds = new Rectangle();
        DrawContext graphics = new DrawContext(minecraft, minecraft.getBufferBuilders().getEntityVertexConsumers());
        
        int index = 0;
        for (EntryStack<?> stack : list) {
            int x = index % side;
            int y = index / side;
            bounds.setBounds(x * RESOLUTION, y * RESOLUTION, RESOLUTION, RESOLUTION);
            ((EntryRenderer<Object>) stack.getDefinition().getRenderer()).render((EntryStack<Object>) stack, graphics, bounds, -1, -1, 0);
            hash.put(EntryStacks.hashExact(stack), pack(x, y));
            index++;
        }
        
        NativeImage nativeImage = new NativeImage(width, height, false);
        RenderSystem.bindTexture(target.getColorAttachment());
        nativeImage.loadFromTextureImage(0, false);
        nativeImage.mirrorVertically();
        
        cachedTexture = new NativeImageBackedTexture(nativeImage);
        cachedTextureLocation = minecraft.getTextureManager().registerDynamicTexture("rei_cached_entries", cachedTexture);
        renderType.reset();
        
        target.delete();
        MinecraftClient.getInstance().worldRenderer.reloadTransparencyPostProcessor();
        MinecraftClient.getInstance().getFramebuffer().beginWrite(true);
        
        modelViewStack.popMatrix();
        RenderSystem.applyModelViewMatrix();
    }
    
    private static long pack(int x, int y) {
        return ((long) x << 32) | (y & 0xFFFFFFFFL);
    }
}
