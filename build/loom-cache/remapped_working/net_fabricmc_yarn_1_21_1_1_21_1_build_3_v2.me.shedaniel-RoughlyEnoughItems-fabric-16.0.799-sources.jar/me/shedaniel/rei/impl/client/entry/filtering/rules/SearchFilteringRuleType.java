/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.entry.filtering.rules;

import com.google.common.collect.Lists;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.entry.filtering.FilteringRuleType;
import me.shedaniel.rei.api.client.registry.entry.EntryRegistry;
import me.shedaniel.rei.api.client.search.SearchFilter;
import me.shedaniel.rei.api.client.search.SearchProvider;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.impl.client.gui.screen.generic.OptionEntriesScreen;
import me.shedaniel.rei.impl.client.gui.widget.BatchedEntryRendererManager;
import me.shedaniel.rei.impl.client.gui.widget.EntryWidget;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import static me.shedaniel.rei.impl.client.gui.widget.entrylist.EntryListWidget.entrySize;

public enum SearchFilteringRuleType implements FilteringRuleType<SearchFilteringRule> {
    INSTANCE;
    
    @Override
    public NbtCompound saveTo(SearchFilteringRule rule, NbtCompound tag) {
        tag.putString("filter", rule.filterStr);
        tag.putBoolean("show", rule.show);
        return tag;
    }
    
    @Override
    public SearchFilteringRule readFrom(NbtCompound tag) {
        String filter = tag.getString("filter");
        boolean show = tag.getBoolean("show");
        return new SearchFilteringRule(filter, show);
    }
    
    @Override
    public SearchFilteringRule createNew() {
        return new SearchFilteringRule("", false);
    }
    
    @Override
    public Text getTitle(SearchFilteringRule rule) {
        return Text.translatable("rule.roughlyenoughitems.filtering.search");
    }
    
    @Override
    public Text getSubtitle(SearchFilteringRule rule) {
        return Text.translatable("rule.roughlyenoughitems.filtering.search.subtitle");
    }
    
    @Override
    @Nullable
    public Function<Screen, Screen> createEntryScreen(SearchFilteringRule rule) {
        return screen -> new OptionEntriesScreen(Text.translatable("config.roughlyenoughitems.filteringRulesScreen"), screen) {
            TextFieldListEntry entry = null;
            BooleanListEntry show = null;
            List<EntryWidget> entryStacks = new ArrayList<>();
            
            @Override
            public void addEntries(Consumer<ListEntry> entryConsumer) {
                addEmpty(entryConsumer, 10);
                addText(entryConsumer, Text.translatable("rule.roughlyenoughitems.filtering.search.filter").formatted(Formatting.GRAY));
                entryConsumer.accept(entry = new TextFieldListEntry(width - 36, widget -> {
                    widget.setMaxLength(9999);
                    widget.setChangedListener(searchTerm -> {
                        SearchFilter filter = SearchProvider.getInstance().createFilter(searchTerm);
                        entryStacks = EntryRegistry.getInstance().getEntryStacks().parallel()
                                .filter(filter)
                                .map(EntryStack::normalize)
                                .map(stack -> new EntryWidget(new Rectangle(0, 0, 18, 18)).noBackground().entry(stack))
                                .collect(Collectors.toList());
                    });
                    if (entry != null) widget.setText(entry.getWidget().getText());
                    else widget.setText(rule.filterStr);
                }));
                addEmpty(entryConsumer, 10);
                addText(entryConsumer, Text.translatable("rule.roughlyenoughitems.filtering.search.show").formatted(Formatting.GRAY));
                Function<Boolean, Text> function = bool -> {
                    return Text.translatable("rule.roughlyenoughitems.filtering.search.show." + bool);
                };
                entryConsumer.accept(show = new BooleanListEntry(width - 36, show == null ? rule.show : show.getBoolean(), function));
                addEmpty(entryConsumer, 10);
                entryConsumer.accept(new SubListEntry(() -> function.apply(show == null ? rule.show : show.getBoolean()),
                        Collections.singletonList(new EntryStacksRuleEntry(() -> entryStacks))));
            }
            
            @Override
            public void save() {
                rule.setFilter(entry.getWidget().getText());
                rule.show = show.getBoolean();
            }
        };
    }
    
    @Override
    public boolean isSingular() {
        return false;
    }
    
    public static class EntryStacksRuleEntry extends OptionEntriesScreen.ListEntry {
        private final Supplier<Iterable<EntryWidget>> entryStacks;
        private int totalHeight;
        
        public EntryStacksRuleEntry(Supplier<Iterable<EntryWidget>> entryStacks) {
            this.entryStacks = entryStacks;
        }
        
        @Override
        public void render(DrawContext graphics, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isHovered, float delta) {
            BatchedEntryRendererManager<EntryWidget> manager = new BatchedEntryRendererManager<>();
            int entrySize = entrySize();
            int width = entryWidth / entrySize;
            int i = 0;
            for (EntryWidget stack : entryStacks.get()) {
                stack.getBounds().setLocation(x + (i % width) * entrySize, y + (i / width) * entrySize);
                if (stack.getBounds().getMaxY() >= 0 && stack.getBounds().getY() <= MinecraftClient.getInstance().getWindow().getScaledHeight()) {
                    manager.add(stack);
                }
                i++;
            }
            manager.render(graphics, mouseX, mouseY, delta);
            totalHeight = (i / width + 1) * entrySize;
        }
        
        @Override
        public int getItemHeight() {
            return totalHeight;
        }
        
        @Override
        public List<? extends Selectable> narratables() {
            return Lists.newArrayList();
        }
        
        @Override
        public List<? extends Element> children() {
            return Lists.newArrayList();
        }
    }
}
