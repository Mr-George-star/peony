/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.fabric;

import me.shedaniel.rei.impl.client.ErrorDisplayer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;

public class ErrorDisplayerImpl implements ErrorDisplayer.ErrorGuiInitializer {
    public static List<Consumer<Screen>> consumerList = new ArrayList<>();
    
    @Override
    public void registerGuiInit(UnaryOperator<Screen> consumer) {
        consumerList.add(screen -> {
            if (screen != MinecraftClient.getInstance().currentScreen) return;
            Screen screen1 = consumer.apply(screen);
            if (screen1 != null) {
                MinecraftClient minecraft = MinecraftClient.getInstance();
                try {
                    if (minecraft.currentScreen != null) minecraft.currentScreen.removed();
                } catch (Throwable ignored) {
                }
                minecraft.currentScreen = null;
                minecraft.setScreen(screen1);
            }
        });
    }
}
