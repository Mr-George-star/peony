/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.gui.screen;

import com.google.common.collect.ImmutableList;
import me.shedaniel.rei.RoughlyEnoughItemsState;
import me.shedaniel.rei.impl.client.gui.InternalTextures;
import me.shedaniel.rei.impl.client.gui.widget.DynamicErrorFreeEntryListWidget;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.screen.narration.NarrationPart;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Pair;
import net.minecraft.util.Util;
import org.jetbrains.annotations.ApiStatus;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

@ApiStatus.Internal
public class WarningAndErrorScreen extends Screen {
    private ClickableWidget buttonExit;
    private StringEntryListWidget listWidget;
    private String action;
    private Screen parent;
    private List<Pair<String, String>> warnings;
    private List<Pair<String, String>> errors;
    private Consumer<Screen> onContinue;
    
    public WarningAndErrorScreen(String action, List<Pair<String, String>> warnings, List<Pair<String, String>> errors, Consumer<Screen> onContinue) {
        super(Text.empty());
        this.action = action;
        this.warnings = warnings;
        this.errors = errors;
        this.onContinue = onContinue;
    }
    
    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }
    
    public void setParent(Screen parent) {
        this.parent = parent;
    }
    
    private void addText(Text string) {
        for (OrderedText s : textRenderer.wrapLines(string, width - 80)) {
            listWidget.creditsAddEntry(new TextItem(s));
        }
    }
    
    private void addLink(Text string, String link) {
        for (OrderedText s : textRenderer.wrapLines(string, width - 80)) {
            listWidget.creditsAddEntry(new LinkItem(s, link));
        }
    }
    
    @Override
    public void init() {
        addSelectableChild(listWidget = new StringEntryListWidget(client, width, height, 32, height - 32));
        listWidget.max = 80;
        listWidget.creditsClearEntries();
        listWidget.creditsAddEntry(new EmptyItem());
        if (!warnings.isEmpty())
            listWidget.creditsAddEntry(new TextItem(Text.literal("Warnings:").formatted(Formatting.GOLD).asOrderedText()));
        for (Pair<String, String> pair : warnings) {
            addText(Text.literal(pair.getLeft()));
            if (pair.getRight() != null)
                addLink(Text.literal(pair.getRight()), pair.getRight());
            for (int i = 0; i < 2; i++) {
                listWidget.creditsAddEntry(new EmptyItem());
            }
        }
        if (!warnings.isEmpty() && !errors.isEmpty()) {
            listWidget.creditsAddEntry(new EmptyItem());
        }
        if (!errors.isEmpty())
            listWidget.creditsAddEntry(new TextItem(Text.literal("Errors:").formatted(Formatting.RED).asOrderedText()));
        for (Pair<String, String> pair : errors) {
            addText(Text.literal(pair.getLeft()));
            if (pair.getRight() != null)
                addLink(Text.literal(pair.getRight()), pair.getRight());
            for (int i = 0; i < 2; i++) {
                listWidget.creditsAddEntry(new EmptyItem());
            }
        }
        for (StringItem child : listWidget.children()) {
            listWidget.max = Math.max(listWidget.max, child.getWidth());
        }
        addDrawableChild(buttonExit = new ButtonWidget(width / 2 - 100, height - 26, 200, 20,
                Text.literal(errors.isEmpty() ? "Continue" : "Exit"),
                button -> onContinue.accept(parent), Supplier::get) {});
    }
    
    @Override
    public boolean mouseScrolled(double double_1, double double_2, double amountX, double amountY) {
        return listWidget.mouseScrolled(double_1, double_2, amountX, amountY) || super.mouseScrolled(double_1, double_2, amountX, amountY);
    }
    
    @Override
    public void render(DrawContext graphics, int int_1, int int_2, float float_1) {
        super.render(graphics, int_1, int_2, float_1);
        this.listWidget.render(graphics, int_1, int_2, float_1);
        if (RoughlyEnoughItemsState.getErrors().isEmpty()) {
            graphics.drawCenteredTextWithShadow(this.textRenderer, "Warnings during Roughly Enough Items' " + action, this.width / 2, 16, 16777215);
        } else {
            graphics.drawCenteredTextWithShadow(this.textRenderer, "Errors during Roughly Enough Items' " + action, this.width / 2, 16, 16777215);
        }
        this.buttonExit.render(graphics, int_1, int_2, float_1);
    }
    
    private static class StringEntryListWidget extends DynamicErrorFreeEntryListWidget<StringItem> {
        private boolean inFocus;
        private int max = 80;
        
        public StringEntryListWidget(MinecraftClient client, int width, int height, int startY, int endY) {
            super(client, width, height, startY, endY, InternalTextures.LEGACY_DIRT);
        }
        
        public void creditsClearEntries() {
            clearItems();
        }
        
        private StringItem rei_getEntry(int int_1) {
            return this.children().get(int_1);
        }
        
        public void creditsAddEntry(StringItem entry) {
            addItem(entry);
        }
        
        @Override
        public int getItemWidth() {
            return max;
        }
        
        @Override
        protected int getScrollbarPosition() {
            return width - 40;
        }
    }
    
    private abstract static class StringItem extends DynamicErrorFreeEntryListWidget.Entry<StringItem> {
        public abstract int getWidth();
        
        @Override
        public void setFocused(boolean bl) {
        }
        
        @Override
        public boolean isFocused() {
            return false;
        }
    }
    
    private static class EmptyItem extends StringItem {
        @Override
        public void render(DrawContext graphics, int i, int i1, int i2, int i3, int i4, int i5, int i6, boolean b, float v) {
        
        }
        
        @Override
        public int getItemHeight() {
            return 5;
        }
        
        @Override
        public int getWidth() {
            return 0;
        }
        
        @Override
        public List<? extends Selectable> narratables() {
            return Collections.emptyList();
        }
    }
    
    private static class TextItem extends StringItem {
        private OrderedText text;
        
        public TextItem(OrderedText text) {
            this.text = text;
        }
        
        @Override
        public void render(DrawContext graphics, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isSelected, float delta) {
            graphics.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, x + 5, y, -1);
        }
        
        @Override
        public int getItemHeight() {
            return 12;
        }
        
        @Override
        public int getWidth() {
            return MinecraftClient.getInstance().textRenderer.getWidth(text) + 10;
        }
        
        @Override
        public List<? extends Selectable> narratables() {
            return ImmutableList.of(new Selectable() {
                public SelectionType getType() {
                    return SelectionType.HOVERED;
                }
                
                public void appendNarrations(NarrationMessageBuilder narrationElementOutput) {
                    StringBuilder builder = new StringBuilder();
                    text.accept((i, style, j) -> {
                        builder.append(Character.toChars(j));
                        return false;
                    });
                    narrationElementOutput.put(NarrationPart.TITLE, builder.toString());
                }
            });
        }
    }
    
    private class LinkItem extends StringItem {
        private OrderedText text;
        private String link;
        private boolean contains;
        
        public LinkItem(OrderedText text, String link) {
            this.text = text;
            this.link = link;
        }
        
        @Override
        public void render(DrawContext graphics, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isSelected, float delta) {
            contains = mouseX >= x && mouseX <= x + entryWidth && mouseY >= y && mouseY <= y + entryHeight;
            if (contains) {
                graphics.drawTooltip(textRenderer, Text.literal("Click to open link."), mouseX, mouseY);
                graphics.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, characterVisitor -> {
                    return text.accept((charIndex, style, codePoint) -> characterVisitor.accept(charIndex, style.withFormatting(Formatting.UNDERLINE), codePoint));
                }, x + 5, y, 0xff1fc3ff);
            } else {
                graphics.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, text, x + 5, y, 0xff1fc3ff);
            }
        }
        
        @Override
        public int getItemHeight() {
            return 12;
        }
        
        @Override
        public int getWidth() {
            return MinecraftClient.getInstance().textRenderer.getWidth(text) + 10;
        }
        
        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            if (contains && button == 0) {
                MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0F));
                try {
                    Util.getOperatingSystem().open(new URI(link));
                    return true;
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }
            }
            return false;
        }
        
        @Override
        public List<? extends Selectable> narratables() {
            return ImmutableList.of(new Selectable() {
                public SelectionType getType() {
                    return SelectionType.HOVERED;
                }
                
                public void appendNarrations(NarrationMessageBuilder narrationElementOutput) {
                    StringBuilder builder = new StringBuilder();
                    text.accept((i, style, j) -> {
                        builder.append(Character.toChars(j));
                        return false;
                    });
                    narrationElementOutput.put(NarrationPart.TITLE, builder.toString());
                }
            });
        }
    }
}
