/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.gui.config.options;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class OptionCategory {
    private final String key;
    private final Identifier icon;
    private final Text name;
    private final Text description;
    private final List<OptionGroup> groups = new ArrayList<>();
    
    private OptionCategory(String key, Identifier icon, Text name, Text description) {
        this.key = key;
        this.icon = icon;
        this.name = name;
        this.description = description;
    }
    
    public static OptionCategory of(String key, Identifier icon, Text name, Text description) {
        return new OptionCategory(key, icon, name, description);
    }
    
    public OptionCategory add(OptionGroup group) {
        this.groups.add(group);
        return this;
    }
    
    public String getKey() {
        return key;
    }
    
    public Identifier getIcon() {
        return icon;
    }
    
    public Text getName() {
        return name;
    }
    
    public Text getDescription() {
        return description;
    }
    
    public List<OptionGroup> getGroups() {
        return groups;
    }
    
    public OptionCategory copy() {
        OptionCategory category = new OptionCategory(key, icon, name, description);
        for (OptionGroup group : groups) {
            category.add(group.copy());
        }
        return category;
    }
}
