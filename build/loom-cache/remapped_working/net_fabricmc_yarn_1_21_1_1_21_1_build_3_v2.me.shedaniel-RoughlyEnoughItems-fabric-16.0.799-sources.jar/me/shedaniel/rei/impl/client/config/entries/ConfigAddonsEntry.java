/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.config.entries;

import com.google.common.collect.ImmutableList;
import me.shedaniel.clothconfig2.api.AbstractConfigListEntry;
import me.shedaniel.rei.api.client.REIRuntime;
import me.shedaniel.rei.impl.client.config.addon.ConfigAddonsScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.util.Window;
import net.minecraft.text.Text;
import net.minecraft.util.Unit;
import org.jetbrains.annotations.ApiStatus;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

@ApiStatus.Internal
public class ConfigAddonsEntry extends AbstractConfigListEntry<Unit> {
    private int width;
    private ClickableWidget buttonWidget = new ButtonWidget(0, 0, 0, 20, Text.empty(), button -> {
        MinecraftClient.getInstance().setScreen(new ConfigAddonsScreen(MinecraftClient.getInstance().currentScreen));
    }, Supplier::get) {
    };
    private List<ClickableWidget> children = ImmutableList.of(buttonWidget);
    
    public ConfigAddonsEntry(int width) {
        super(Text.empty(), false);
        this.width = width;
        this.buttonWidget.setMessage(REIRuntime.getInstance().getPreviousContainerScreen() != null && MinecraftClient.getInstance().getNetworkHandler() != null
                && MinecraftClient.getInstance().getNetworkHandler().getRecipeManager() != null ? Text.translatable("text.rei.addons")
                : Text.translatable("config.roughlyenoughitems.filteredEntries.loadWorldFirst"));
    }
    
    @Override
    public Unit getValue() {
        return Unit.INSTANCE;
    }
    
    @Override
    public Optional<Unit> getDefaultValue() {
        return Optional.of(Unit.INSTANCE);
    }
    
    @Override
    public void save() {
    }
    
    @Override
    public void render(DrawContext graphics, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isSelected, float delta) {
        super.render(graphics, index, y, x, entryWidth, entryHeight, mouseX, mouseY, isSelected, delta);
        Window window = MinecraftClient.getInstance().getWindow();
        this.buttonWidget.active = REIRuntime.getInstance().getPreviousContainerScreen() != null && MinecraftClient.getInstance().getNetworkHandler() != null
                                   && MinecraftClient.getInstance().getNetworkHandler().getRecipeManager() != null && this.isEditable();
        this.buttonWidget.setY(y);
        this.buttonWidget.setX(x + entryWidth / 2 - width / 2);
        this.buttonWidget.setWidth(width);
        this.buttonWidget.render(graphics, mouseX, mouseY, delta);
    }
    
    @Override
    public List<? extends Element> children() {
        return children;
    }
    
    @Override
    public List<? extends Selectable> narratables() {
        return children;
    }
}
