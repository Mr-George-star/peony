/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.util;

import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.impl.client.gui.widget.CatchingExceptionUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;

public class CrashReportUtils {
    public static CrashReport essential(Throwable throwable, String task) {
        Throwable temp = throwable;
        while (temp != null) {
            temp = temp.getCause();
            if (temp instanceof CrashException) {
                return essential(temp, task);
            }
        }
        CrashReport report = CrashReport.create(throwable, task);
        screen(report, MinecraftClient.getInstance().currentScreen);
        return report;
    }
    
    private static void screen(CrashReport report, Screen screen) {
        if (screen != null) {
            CrashReportSection category = report.addElement("Screen details");
            String screenName = screen.getClass().getCanonicalName();
            category.add("Screen name", () -> screenName);
        }
    }
    
    public static void renderer(CrashReport report, Renderer renderer) {
        if (renderer != null) {
            CrashReportSection category = report.addElement("Renderer details");
            try {
                renderer.fillCrashReport(report, category);
            } catch (Throwable throwable) {
                category.add("Filling Report", throwable);
            }
        }
    }
    
    public static CrashException throwReport(CrashReport report) {
        return new CrashException(report);
    }
    
    public static void catchReport(CrashReport report) {
        CatchingExceptionUtils.handleThrowable(new CrashException(report), report.getMessage());
    }
}
