/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.gui.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import me.shedaniel.rei.impl.client.gui.InternalTextures;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.text.Text;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Matrix4f;

@ApiStatus.Internal
public class SearchFilterSyntaxHighlightingScreen extends Screen {
    protected SearchFilterSyntaxHighlightingScreen(Text component) {
        super(component);
    }
    
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        renderHoleBackground(graphics, 0, height, 32, 255, 255);
        super.render(graphics, mouseX, mouseY, delta);
    }
    
    protected void renderHoleBackground(DrawContext graphics, int y1, int y2, int tint, int alpha1, int alpha2) {
        Tessellator tesselator = Tessellator.getInstance();
        RenderSystem.setShaderTexture(0, InternalTextures.LEGACY_DIRT);
        Matrix4f matrix = graphics.getMatrices().peek().getPositionMatrix();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
        BufferBuilder buffer = tesselator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(matrix, 0, y2, 0.0F).texture(0.0F, y2 / 32.0F).color(tint, tint, tint, alpha2);
        buffer.vertex(matrix, this.width, y2, 0.0F).texture(this.width / 32.0F, y2 / 32.0F).color(tint, tint, tint, alpha2);
        buffer.vertex(matrix, this.width, y1, 0.0F).texture(this.width / 32.0F, y1 / 32.0F).color(tint, tint, tint, alpha1);
        buffer.vertex(matrix, 0, y1, 0.0F).texture(0.0F, y1 / 32.0F).color(tint, tint, tint, alpha1);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }
}
